import 'dart:convert';
import 'package:conport/models/report.dart';
import 'package:http/http.dart' as http;

import '../models/unidade.dart';

class supervisorService{

    final String UrlBase = "http://localhost:8080";


    /*
    FAZER DEPOIS, AINDA FALTA FAZER ESSA INTEGRAÇÃO CORRETA, PFVR FAÇA SUE PUTO
    */
    
}