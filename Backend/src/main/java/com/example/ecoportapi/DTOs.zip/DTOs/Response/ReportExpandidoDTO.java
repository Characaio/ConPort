package com.example.ecoportapi.DTOs.Response;

import java.util.List;

public record ReportExpandidoDTO(
        Long Id,
        String Tipo,
        String Status,
        String DataDoOcorrido,
        String Local,
        String Descricao,
        List<String> ImagensNomes,
        String UsuarioNome,
        String SupervisorNome,
        String DataDaAnalise
) {}
